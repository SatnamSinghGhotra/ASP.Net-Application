﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


namespace SatnamC0738849_Assignment3
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SatnamDBConnection"].ConnectionString);
                conn.Open();
                string checkuser = "select count(*) from [dbo].[ CSD3354_tbl] where StudentName='" + TextBox1.Text + "'";
                SqlCommand cmd = new SqlCommand(checkuser, conn);
                int temp = Convert.ToInt32(cmd.ExecuteScalar().ToString());

                if (temp == 1)
                {
                    Response.Write("Student Already Exist");
                }

                conn.Close();

            }

        }

        protected void RegisterBtn_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SatnamDBConnection"].ConnectionString);
                conn.Open();
                string insertQuery = "insert into[ CSD3354_tbl](StudentID,StudentName,Assignment1,Assignment2,Assignment3,Assignment4,Assignment5,Test1,Test2,Test3,CourseTotal,GPA,Grade) values (@studentid,@studentname,@Assignment1,@Assignment2,@Assignment3,@Assignment4,@Assignment5,@Test1,@Test2,@Test3,@CTotal,@GPA,@Grade)";
                SqlCommand cmd = new SqlCommand(insertQuery, conn);
                cmd.Parameters.AddWithValue("@studentid", TextBox6.Text);
                cmd.Parameters.AddWithValue("@studentname", TextBox1.Text);
                cmd.Parameters.AddWithValue("@Assignment1", TextBox2.Text);
                cmd.Parameters.AddWithValue("@Assignment2", TextBox3.Text);
                cmd.Parameters.AddWithValue("@Assignment3", TextBox4.Text);
                cmd.Parameters.AddWithValue("@Assignment4", TextBox5.Text);
                cmd.Parameters.AddWithValue("@Assignment5", TextBox7.Text);
                cmd.Parameters.AddWithValue("@Test1", TextBox8.Text);
                cmd.Parameters.AddWithValue("@Test2", TextBox9.Text);
                cmd.Parameters.AddWithValue("@Test3", TextBox10.Text);
                cmd.Parameters.AddWithValue("@CTotal", txtTotal.Text);
                cmd.Parameters.AddWithValue("@GPA", txtGPA.Text);
                cmd.Parameters.AddWithValue("@Grade", txtGrade.Text);
                cmd.ExecuteNonQuery();

                Response.Write("Student registeration Successfully!!!thank you");

                conn.Close();

            }
            catch (Exception ex)
            {
                Response.Write("error" + ex.ToString());
            }

        }

        protected void ViewdataBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("ShowData.aspx");
        }

        protected void CalcTotal_Click(object sender, EventArgs e)
        {

            double a1, a2, a3, a4, a5;//assignment local variables
            double t1, t2, t3; //tests local variables
            double testTotal, assignTotal, courseTotal, GPA;
            string grades;
            testTotal = assignTotal = courseTotal = 0.0;

            //Assign the values from textboxes to local variables
            a1 = double.Parse(TextBox2.Text);
            a2 = double.Parse(TextBox3.Text);
            a3 = double.Parse(TextBox4.Text);
            a4 = double.Parse(TextBox5.Text);
            a5 = double.Parse(TextBox7.Text);
            assignTotal = a1 * 0.05 + a2 * 0.05 + a3 * 0.05 + a4 * 0.05 + a5 * 0.05;

            t1 = double.Parse(TextBox8.Text);
            t2 = double.Parse(TextBox9.Text);
            t3 = double.Parse(TextBox10.Text);
            testTotal = t1 * 0.25 + t2 * 0.25 + t3 * 0.25;

            courseTotal = assignTotal + testTotal;

            //find the grade 
            if (courseTotal >= 94.00 && courseTotal <= 100)
                grades = "A+";
            else if (courseTotal >= 87.00 && courseTotal <= 93.99)
                grades = "A";
            else if (courseTotal >= 80.00 && courseTotal <= 86.99)
                grades = "A-";
            else if (courseTotal >= 77.00 && courseTotal <= 79.99)
                grades = "B+";
            else if (courseTotal >= 73.00 && courseTotal <= 76.99)
                grades = "B";
            else if (courseTotal >= 70.00 && courseTotal <= 72.99)
                grades = "B-";
            else if (courseTotal >= 67.00 && courseTotal <= 69.99)
                grades = "C+";
            else if (courseTotal >= 63.00 && courseTotal <= 66.99)
                grades = "C";
            else if (courseTotal >= 60.00 && courseTotal <= 62.99)
                grades = "C-";
            else if (courseTotal >= 50.00 && courseTotal <= 59.99)
                grades = "D";
            else
                grades = "F";
            if (courseTotal >= 94.00 && courseTotal <= 100)
                grades = "A+";
            else if (courseTotal >= 87.00 && courseTotal <= 93.99)
                grades = "A";
            else if (courseTotal >= 80.00 && courseTotal <= 86.99)
                grades = "A-";
            else if (courseTotal >= 77.00 && courseTotal <= 79.99)
                grades = "B+";
            else if (courseTotal >= 73.00 && courseTotal <= 76.99)
                grades = "B";
            else if (courseTotal >= 70.00 && courseTotal <= 72.99)
                grades = "B-";
            else if (courseTotal >= 67.00 && courseTotal <= 69.99)
                grades = "C+";
            else if (courseTotal >= 63.00 && courseTotal <= 66.99)
                grades = "C";
            else if (courseTotal >= 60.00 && courseTotal <= 62.99)
                grades = "C-";
            else if (courseTotal >= 50.00 && courseTotal <= 59.99)
                grades = "D";
            else
                grades = "F";


            if (courseTotal >= 94.00 && courseTotal <= 100)
                GPA = 4.0;
            else if (courseTotal >= 87.00 && courseTotal <= 93.99)
                GPA = 3.7;
            else if (courseTotal >= 80.00 && courseTotal <= 86.99)
                GPA = 3.5;
            else if (courseTotal >= 77.00 && courseTotal <= 79.99)
                GPA = 3.2;
            else if (courseTotal >= 73.00 && courseTotal <= 76.99)
                GPA = 3.0;
            else if (courseTotal >= 70.00 && courseTotal <= 72.99)
                GPA = 2.7;
            else if (courseTotal >= 67.00 && courseTotal <= 69.99)
                GPA = 2.3;
            else if (courseTotal >= 63.00 && courseTotal <= 66.99)
                GPA = 2.0;
            else if (courseTotal >= 60.00 && courseTotal <= 62.99)
                GPA = 1.7;
            else if (courseTotal >= 50.00 && courseTotal <= 59.99)
                GPA = 1.0;
            else
                GPA = 0.0;
            txtTotal.Text = courseTotal.ToString();
            txtGrade.Text = grades;
            txtGPA.Text = GPA.ToString();
        }
    }
}