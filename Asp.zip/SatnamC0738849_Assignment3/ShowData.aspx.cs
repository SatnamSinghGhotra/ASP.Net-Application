﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


namespace SatnamC0738849_Assignment3
{
    public partial class ShowData : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["SatnamDBConnection"].ConnectionString;
        SqlConnection con;
        SqlDataAdapter adapt;
        DataTable dt;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Showdata();
            }

        }
        protected void Showdata()
        {
            dt = new DataTable();
            con = new SqlConnection(cs);
            con.Open();
            adapt = new SqlDataAdapter("SELECT [StudentID], [StudentName], [Assignment1], [Assignment2], [Assignment3], [Assignment4], [Assignment5], [Test1], [Test2], [Test3], [CourseTotal], [GPA], [Grade] FROM [ CSD3354_tbl]", con);
            adapt.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GridView2.DataSource = dt;
                GridView2.DataBind();
            }
            con.Close();
        }

        protected void GridView2_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
        {
            //NewEditIndex property used to determine the index of the row being edited.  
            GridView2.EditIndex = e.NewEditIndex;
            Showdata();
        }
        protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            con = new SqlConnection(cs);
            con.Open();
            Label StudentID = GridView2.Rows[e.RowIndex].FindControl("lbl_ID") as Label;

            string mystr = "Delete [ CSD3354_tbl] where StudentID= '" + StudentID.Text + "'";
            SqlCommand cmd = new SqlCommand(mystr, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Showdata();
        }

        protected void GridView2_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
        {
            //Finding the controls from Gridview for the row which is going to update  
            Label StudentID = GridView2.Rows[e.RowIndex].FindControl("lbl_ID") as Label;
            TextBox StudentName = GridView2.Rows[e.RowIndex].FindControl("TextBox1") as TextBox;
            TextBox Assignment1 = GridView2.Rows[e.RowIndex].FindControl("TextBox2") as TextBox;
            TextBox Assignment2 = GridView2.Rows[e.RowIndex].FindControl("TextBox3") as TextBox;
            TextBox Assignment3 = GridView2.Rows[e.RowIndex].FindControl("TextBox4") as TextBox;
            TextBox Assignment4 = GridView2.Rows[e.RowIndex].FindControl("TextBox5") as TextBox;
            TextBox Assignment5 = GridView2.Rows[e.RowIndex].FindControl("TextBox7") as TextBox;
            TextBox Test1 = GridView2.Rows[e.RowIndex].FindControl("TextBox8") as TextBox;
            TextBox Test2 = GridView2.Rows[e.RowIndex].FindControl("TextBox9") as TextBox;
            TextBox Test3 = GridView2.Rows[e.RowIndex].FindControl("TextBox10") as TextBox;
            TextBox CourseTotal = GridView2.Rows[e.RowIndex].FindControl("txtTotal") as TextBox;
            TextBox GPA = GridView2.Rows[e.RowIndex].FindControl("txtGPA") as TextBox;
            TextBox Grade = GridView2.Rows[e.RowIndex].FindControl("txtGrade") as TextBox;
            con = new SqlConnection(cs);
            con.Open();
            //updating the record  
            SqlCommand cmd = new SqlCommand("Update [ CSD3354_tbl] set  StudentName='" + StudentName.Text + "', Assignment1= '" + Assignment1.Text + "', Assignment2='" + Assignment2.Text + "', Assignment3='" + Assignment3.Text + "', Assignment4='" + Assignment4.Text + "', Assignment5='" + Assignment5.Text + "', Test1='" + Test1.Text + "',Test2='" + Test2.Text + "',Test3='" + Test3.Text + "',CourseTotal='" + CourseTotal.Text + "',GPA='" + GPA.Text + "',Grade='" + Grade.Text + "' where   StudentID='" + StudentID.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview  
            GridView2.EditIndex = -1;
            //Call ShowData method for displaying updated data  
            Showdata();
        }
        protected void GridView2_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
        {
            //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview  
            GridView2.EditIndex = -1;
            Showdata();
        }



    }



}    
